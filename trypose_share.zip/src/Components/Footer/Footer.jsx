import React from 'react';
import './Footer.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faFacebook, faTwitter, faInstagram } from '@fortawesome/free-brands-svg-icons';
import logo from '../../Assests/image.svg';
import { Link } from 'react-router-dom';

function Footer() {
  return (
    <footer className="footer-container">
      <div className="footer-column social-media-column">
        <h4 className='logo-footer'>
          <img src={logo} alt='logoimage'/>trypose
        </h4>
        <div className="social-icons">
          <a href="https://www.facebook.com/yourpage" target="_blank" rel="noopener noreferrer"><FontAwesomeIcon icon={faFacebook} /></a>
          <a href="https://www.twitter.com/yourpage" target="_blank" rel="noopener noreferrer"><FontAwesomeIcon icon={faTwitter} /></a>
          <a href="https://www.instagram.com/yourpage" target="_blank" rel="noopener noreferrer"><FontAwesomeIcon icon={faInstagram} /></a>
        </div>
      </div>
      <div className="footer-column">
        <div className="heading">
          <Link to="/cloth-store">Cloth Store</Link>
          <Link to="/about">ABOUT</Link>
          <Link to="/collabs">COLLABS</Link>
          <Link to="/gift-card">GIFT CARD</Link>
          <Link to="/official-stores">OFFICIAL STORES</Link>
          <Link to="/refer-a-friend">REFER A FRIEND</Link>
        </div>
      </div>
      <div className="footer-column">
        <div className="heading">
          <Link to="/contact">CONTACT</Link>
          <Link to="/payments">PAYMENTS</Link>
          <Link to="/shipping-and-delivery">SHIPPING AND DELIVERY</Link>
          <Link to="/returns-and-refunds">RETURNS AND REFUNDS</Link>
        </div>
      </div>
      <div className="footer-column">

        <h1>DON'T WANT TO MISS OUT?</h1>
        <p>Be the first to know about new product releases, limited edition items, and much more.</p>
        <button>SUBSCRIBE</button>
      </div>
    </footer>
  );
}

export default Footer;
